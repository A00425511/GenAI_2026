"""Deterministic fictional retail transaction data, used only in explicitly labeled demo mode."""
from pathlib import Path
import numpy as np
import pandas as pd

COLUMNS = ['transaction_id','date','customer_id','category','region','customer_segment','revenue']

def generate(seed=42):
    rng = np.random.default_rng(seed)
    rows=[]
    tid=0
    for month in range(1,10):
        for category,(low,high) in {'Electronics':(150,500),'Clothing':(30,150),'Home':(50,250),'Sports':(40,200)}.items():
            count=120 if month==9 and category=='Electronics' else 300
            for _ in range(count):
                tid+=1
                rows.append((tid,f'2026-{month:02d}-{int(rng.integers(1,29)):02d}',f'C{int(rng.integers(1,1001)):04d}',category,str(rng.choice(['Atlantic','Ontario','Quebec','Western'])),str(rng.choice(['New','Returning'])),round(float(rng.uniform(low,high)),2)))
    return pd.DataFrame(rows,columns=COLUMNS)

def ensure_csv(path='business_transactions.csv'):
    p=Path(path)
    if not p.exists(): generate().to_csv(p,index=False)
    return p

if __name__=='__main__':
    p=ensure_csv()
    print('Saved',p, 'rows:',len(pd.read_csv(p)))
