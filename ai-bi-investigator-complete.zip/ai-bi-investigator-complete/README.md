# AI Business Intelligence Investigator

A small, evidence-first Streamlit BI investigation application. It compares monthly revenue, tests volume versus average spending, calculates dimension-level contributions, reconciles results, and exposes SQL query traces when running against Zetaris.

## Quick start (offline demo)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python data.py
streamlit run app.py
```

Open the local Streamlit URL. Select **Demo CSV** and click **Investigate**. This is a deterministic, working offline demonstration **not a valid proof of Zetaris, Nightshift, Nemotron, or Meterless Engine integration**.

## Live Zetaris configuration

1. Confirm Zetaris driver is healthy and SQL executes in its UI.
2. Install the Hive client: `pip install 'pyhive[hive]' thrift thrift-sasl` (on some systems SASL requires OS build dependencies).
3. `cp .env.example .env` and fill in your verified credentials and `ZETARIS_TABLE`.
4. Select **Live Zetaris SQL** in the sidebar.

**Required table schema**: `transaction_id`, `date` (ISO `YYYY-MM-DD` or comparable string), `customer_id`, `category`, `region`, `customer_segment`, `revenue`. The live SQL templates use `SUM(revenue)`, `COUNT(*)`, a date range, and groupings. The bundled `ny_taxi` tables almost certainly do **not** match these column names without adaptation. For taxi data, inspect or query the real schema and update `ZetarisSource.get` in `investigator.py` accordingly. This repository does not claim to auto-discover taxi schema.

The Python client assumes HiveServer2 protocol and `auth=NONE` by default; authentication may differ on your Zetaris deployment. Port reachability is not proof of successful authentication. If a connection fails, verify the exact server protocol and auth mode.

## Nightshift + NVIDIA

Nightshift adapter calls `POST {NIGHTSHIFT_BASE_URL}/v1/chat/completions` using `NIGHTSHIFT_MODEL`. Set the model to a **real NVIDIA Nemotron model ID** from your local `/v1/models`. Turn on the checkbox. An HTTP 502 means the external inference service is not working; the app displays an error instead of inventing model output. This endpoint shape is an OpenAI-compatible assumption and must be confirmed against your Nightshift version.

If WSL cannot reach the Windows-hosted runtime via 127.0.0.1, adjust `NIGHTSHIFT_BASE_URL` to the actual reachable address and ensure Windows firewall and service binding allow access.

## Meterless Engine

The optional `MeterlessEngine` is an HTTP event adapter. **It is not a verified H-MEM implementation.** It requires a real, compatible engine endpoint and may require adapting the payload to the actual engine API. The UI fails visibly if enabled but unconfigured. Do not claim the hackathon's Meterless Engine requirement is satisfied until you have demonstrated a real engine call and its effect on behavior.

## Investigation algorithm

- Test transaction volume versus average transaction value using exact decomposition: `(N1-N0)*A0 + N1*(A1-A0)`.
- Group revenue by category, region, and segment and reconcile to the overall change.
- Optional Nightshift model produces hypotheses and a final explanation from evidence.
- The app explicitly avoids asserting causation from observational data.
- SQL uses controlled templates; no arbitrary model-generated SQL is executed.

## Tests

```bash
pytest -q
```

## Submission readiness

| Component | Status in supplied project |
|---|---|
| Offline Streamlit demo and charts | Implemented, tests included |
| Live Zetaris SQL adapter | Implemented but requires real table schema, auth and local verification |
| Nightshift/Nemotron adapter | Implemented but requires working inference endpoint and model ID |
| Meterless Engine | HTTP integration placeholder only; real engine semantics unverified |
| End-to-end hackathon integrations | **Not verified** |

For a hackathon demo, record both the app and direct evidence that each mandatory service actually ran. Do not label offline demo mode as live integrations.
