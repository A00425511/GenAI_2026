"""Real service adapters. No silent fallbacks to demo data or fake AI."""
import os
import requests
import pandas as pd

class ZetarisSQL:
    def __init__(self):
        self.host=os.getenv('ZETARIS_HOST','127.0.0.1')
        self.port=int(os.getenv('ZETARIS_PORT','10000'))
        self.username=os.getenv('ZETARIS_USERNAME','admin@default.com')
        self.password=os.getenv('ZETARIS_PASSWORD','')
        self.auth=os.getenv('ZETARIS_AUTH','NONE').upper()
        self.database=os.getenv('ZETARIS_DATABASE','default')
        self.table=os.getenv('ZETARIS_TABLE','')
        if not self.table: raise ValueError('Set ZETARIS_TABLE to a verified, fully qualified SQL table name.')
        if not all(c.isalnum() or c in '._' for c in self.table):
            raise ValueError('Invalid table identifier')

    def query(self,sql):
        if not sql.strip().lower().startswith(('select ','with ')) or ';' in sql.strip().rstrip(';'):
            raise ValueError('Only one read-only SELECT/WITH statement allowed')
        from pyhive import hive
        kwargs=dict(host=self.host,port=self.port,username=self.username,database=self.database,auth=self.auth)
        if self.password: kwargs['password']=self.password
        conn=hive.Connection(**kwargs)
        try:
            cur=conn.cursor()
            try:
                cur.execute(sql)
                columns=[c[0] for c in cur.description]
                return pd.DataFrame(cur.fetchall(),columns=columns)
            finally: cur.close()
        finally: conn.close()

class Nightshift:
    def __init__(self):
        self.base=os.getenv('NIGHTSHIFT_BASE_URL','http://127.0.0.1:8088').rstrip('/')
        self.model=os.getenv('NIGHTSHIFT_MODEL','')
        self.api_key=os.getenv('NIGHTSHIFT_API_KEY','')
        if not self.model: raise ValueError('Set NIGHTSHIFT_MODEL to a model ID returned by Nightshift /v1/models.')

    def complete(self,system,user):
        headers={'Content-Type':'application/json'}
        if self.api_key: headers['Authorization']='Bearer '+self.api_key
        response=requests.post(self.base+'/v1/chat/completions',headers=headers,json={'model':self.model,'temperature':0.1,'max_tokens':900,'messages':[{'role':'system','content':system},{'role':'user','content':user}]},timeout=100)
        response.raise_for_status()
        return response.json()['choices'][0]['message']['content']

class MeterlessEngine:
    """Optional actual engine HTTP adapter; endpoint/payload must match user's installed engine API."""
    def __init__(self):
        self.endpoint=os.getenv('METERLESS_ENGINE_ENDPOINT','')
        self.key=os.getenv('METERLESS_ENGINE_KEY','')
        if not self.endpoint: raise ValueError('METERLESS_ENGINE_ENDPOINT is not configured')
    def record(self,event):
        headers={'Content-Type':'application/json'}
        if self.key: headers['Authorization']='Bearer '+self.key
        resp=requests.post(self.endpoint,json=event,headers=headers,timeout=15)
        resp.raise_for_status()
        return resp.json() if resp.content else {'status':'accepted'}
