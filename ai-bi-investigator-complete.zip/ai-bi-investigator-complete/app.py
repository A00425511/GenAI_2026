import os
import streamlit as st
import plotly.express as px
import pandas as pd
from dotenv import load_dotenv
from investigator import investigate

load_dotenv()
st.set_page_config(page_title='AI BI Investigator',layout='wide',page_icon='🔎')
st.title('🔎 AI Business Intelligence Investigator')
st.caption('Evidence-first investigations • SQL trace • hypothesis checks • explicit causal uncertainty')
with st.sidebar:
    st.header('Runtime')
    mode=st.radio('Data source',['demo','zetaris'],format_func=lambda x:'Demo CSV (offline)' if x=='demo' else 'Live Zetaris SQL')
    use_ai=st.checkbox('Use Nightshift / NVIDIA model',value=False)
    use_engine=st.checkbox('Record in real Meterless Engine',value=False)
    st.warning('Demo mode is not a substitute for required hackathon integrations.') if mode=='demo' else st.success('Live Zetaris selected')
    a=st.selectbox('Previous month',pd.period_range('2026-01','2026-09',freq='M').astype(str),index=7)
    b=st.selectbox('Current month',pd.period_range('2026-01','2026-09',freq='M').astype(str),index=8)
question=st.text_input('Ask a business question','Why did revenue decline in September 2026?')
if st.button('Investigate',type='primary'):
    try:
        with st.spinner('Collecting and reconciling evidence...'):
            result=investigate(question,mode,use_ai,use_engine,a,b)
        st.session_state['result']=result
    except Exception as e:
        st.error(f'Investigation failed: {type(e).__name__}: {e}')
        st.info('No silent fallback occurred. Check your live connection settings or switch explicitly to Demo.')
if 'result' in st.session_state:
    r=st.session_state['result']; m=r['metrics']
    st.info(f"Data: {r['source']} | Model inference: {'ON' if r['ai_enabled'] else 'OFF'} | Engine: {'ON' if use_engine else 'OFF'}")
    c1,c2,c3,c4=st.columns(4)
    c1.metric('Previous revenue',f"${m['previous_revenue']:,.0f}")
    c2.metric('Current revenue',f"${m['current_revenue']:,.0f}",f"{m['percent']:+.1f}%" if m['percent'] is not None else None)
    c3.metric('Transactions',f"{m['current_trips']:,}",f"{m['current_trips']-m['previous_trips']:+,}")
    c4.metric('Average transaction',f"${m['current_avg']:,.2f}")
    st.subheader('Findings')
    st.write(r['explanation'])
    st.subheader('Contribution analysis')
    st.plotly_chart(px.bar(pd.DataFrame({'factor':['Volume','Average spending'],'change':[m['volume_effect'],m['spending_effect']]}),x='factor',y='change',title='Exact revenue change decomposition'),use_container_width=True)
    tabs=st.tabs(['Categories','Regions','Customer segments','Investigation trace','SQL queries'])
    for tab,dim in zip(tabs[:3],('category','region','customer_segment')):
        with tab:
            frame=r['breakdown'][dim]
            st.plotly_chart(px.bar(frame,x=dim,y='change',title=f'Revenue contribution by {dim}'),use_container_width=True)
            st.dataframe(frame,use_container_width=True,hide_index=True)
    with tabs[3]:
        for i,step in enumerate(r['steps'],1):
            with st.expander(f"{i}. {step['stage']}",expanded=True): st.write(step['detail'])
    with tabs[4]:
        if not r['sql']: st.info('Demo mode used pandas; no SQL queries were executed.')
        for i,entry in enumerate(r['sql'],1):
            st.code(entry['sql'],language='sql'); st.caption(f"Query {i} • {entry['rows']} rows")
else:
    st.write('Choose your data source and click **Investigate**. In demo mode the app runs immediately without external services.')
