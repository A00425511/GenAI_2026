"""Evidence-first BI investigator with auditable SQL and numerical reconciliation."""
import json
import os
import re
import pandas as pd
from data import ensure_csv
from connectors import ZetarisSQL, Nightshift, MeterlessEngine

DIMENSIONS=('category','region','customer_segment')

class DemoSource:
    label='DEMO (local CSV, NOT Zetaris)'
    def __init__(self):
        self.df=pd.read_csv(ensure_csv())
    def get(self,start,end,dimension=None):
        d=self.df[(self.df['date']>=start)&(self.df['date']<end)]
        if dimension:
            return d.groupby(dimension,dropna=False).agg(revenue=('revenue','sum'),trips=('transaction_id','count')).reset_index()
        return pd.DataFrame([{'revenue':d['revenue'].sum(),'trips':len(d)}])

class ZetarisSource:
    label='LIVE (SQL via Zetaris)'
    def __init__(self): self.client=ZetarisSQL()
    def get(self,start,end,dimension=None):
        # Restrict dynamic SQL to known dimensions and validated dates.
        for d in (start,end):
            if not re.fullmatch(r'20\d\d-\d\d-\d\d',d): raise ValueError('Invalid date')
        table=self.client.table
        grouping=f'{dimension}, ' if dimension in DIMENSIONS else ''
        if dimension and dimension not in DIMENSIONS: raise ValueError('Invalid dimension')
        sql=(f'SELECT {grouping}SUM(revenue) AS revenue, COUNT(*) AS trips FROM {table} '
             f"WHERE `date` >= '{start}' AND `date` < '{end}'" + (f' GROUP BY {dimension}' if dimension else ''))
        result=self.client.query(sql)
        self.trace.append({'sql':sql,'rows':len(result)})
        return result

def investigate(question,mode='demo',use_ai=False,use_engine=False,month_a='2026-08',month_b='2026-09'):
    if not re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])',month_a) or not re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])',month_b):
        raise ValueError('Invalid comparison month')
    def bounds(month):
        p=pd.Period(month,freq='M')
        return str(p.start_time.date()),str((p+1).start_time.date())
    source=DemoSource() if mode=='demo' else ZetarisSource()
    source.trace=[]
    steps=[{'stage':'Plan','detail':'Test volume versus average transaction value; investigate category, region, and segment contributions.'}]
    if use_ai:
        model=Nightshift()
        plan=model.complete('You are a cautious BI analyst. Give 3 brief testable hypotheses, no invented evidence.',f'Question: {question}. Compare {month_a} and {month_b}. Available dimensions: {DIMENSIONS}.')
        steps.append({'stage':'Nemotron hypotheses','detail':plan})
    (a0,a1),(b0,b1)=bounds(month_a),bounds(month_b)
    def get(month,start,end,dimension=None):
        frame=source.get(start,end,dimension)
        if 'revenue' not in frame or 'trips' not in frame: raise ValueError('Required columns missing from SQL results')
        frame=frame.copy()
        frame['revenue']=pd.to_numeric(frame['revenue']).fillna(0)
        frame['trips']=pd.to_numeric(frame['trips']).fillna(0)
        return frame
    a=get(month_a,a0,a1).iloc[0]; b=get(month_b,b0,b1).iloc[0]
    oldrev,newrev=float(a.revenue),float(b.revenue)
    oldn,newn=int(a.trips),int(b.trips)
    delta=newrev-oldrev
    oldavg=oldrev/oldn if oldn else 0
    newavg=newrev/newn if newn else 0
    # Exact decomposition: (N1-N0)*A0 + N1*(A1-A0)
    volume=(newn-oldn)*oldavg
    spending=newn*(newavg-oldavg)
    breakdown={}
    for dim in DIMENSIONS:
        old=get(month_a,a0,a1,dim).rename(columns={'revenue':'previous_revenue','trips':'previous_trips'})
        new=get(month_b,b0,b1,dim).rename(columns={'revenue':'current_revenue','trips':'current_trips'})
        merged=old.merge(new,on=dim,how='outer').fillna(0)
        merged['change']=merged['current_revenue']-merged['previous_revenue']
        merged=merged.sort_values('change')
        if abs(float(merged.change.sum())-delta)>0.05:
            raise ValueError(f'{dim} revenue does not reconcile to overall change')
        breakdown[dim]=merged
    steps.append({'stage':'Evidence','detail':f'{month_a}: {oldn:,} transactions, ${oldrev:,.2f}; {month_b}: {newn:,} transactions, ${newrev:,.2f}.'})
    steps.append({'stage':'Verification','detail':f'Volume contribution ${volume:,.2f}; average-spending contribution ${spending:,.2f}; sum ${volume+spending:,.2f} = observed ${delta:,.2f}. All dimensions reconcile.'})
    worst=breakdown['category'].iloc[0]
    base=(f'Revenue changed by ${delta:,.2f} ({100*delta/oldrev:+.1f}%) from {month_a} to {month_b}. '
          f'Transactions changed from {oldn:,} to {newn:,}; average transaction value changed from ${oldavg:,.2f} to ${newavg:,.2f}. '
          f'Volume accounts for ${volume:,.2f} and average spending for ${spending:,.2f} of the change. '
          f'The largest negative category contribution was {worst.category} (${worst.change:,.2f}). '
          'These are accounting contributions, not proof of causal mechanisms.')
    explanation=base
    if use_ai:
        evidence={'question':question,'months':[month_a,month_b],'revenue':[oldrev,newrev],'transactions':[oldn,newn], 'volume_effect':volume,'spending_effect':spending,'top_category_changes':breakdown['category'][['category','change']].to_dict('records')}
        explanation=model.complete('Explain only the supplied evidence. Do not invent facts. Clearly distinguish accounting contributions from causal explanations. Be concise.',json.dumps(evidence,default=str))
        steps.append({'stage':'Nemotron synthesis','detail':explanation})
    engine_status='Not enabled'
    if use_engine:
        engine_status=MeterlessEngine().record({'event_type':'bi_investigation','question':question,'comparison':[month_a,month_b],'delta':delta,'findings':base})
        steps.append({'stage':'Meterless Engine','detail':f'Engine acknowledged investigation: {engine_status}'})
    return {'source':source.label,'metrics':{'previous_revenue':oldrev,'current_revenue':newrev,'change':delta,'percent':100*delta/oldrev if oldrev else None,'previous_trips':oldn,'current_trips':newn,'previous_avg':oldavg,'current_avg':newavg,'volume_effect':volume,'spending_effect':spending},'breakdown':breakdown,'steps':steps,'sql':source.trace,'explanation':explanation,'engine_status':engine_status,'ai_enabled':use_ai}
