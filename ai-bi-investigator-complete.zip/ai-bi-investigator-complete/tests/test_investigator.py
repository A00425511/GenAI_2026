from investigator import investigate
from data import generate

def test_dataset():
    assert len(generate())==10620

def test_decline_and_reconciliation():
    r=investigate('Why did revenue fall?')
    m=r['metrics']
    assert m['change']<0
    assert abs(m['volume_effect']+m['spending_effect']-m['change'])<.01
    for frame in r['breakdown'].values():
        assert abs(frame['change'].sum()-m['change'])<.05

def test_no_live_claim_in_demo():
    r=investigate('Why?')
    assert 'DEMO' in r['source']
    assert not r['sql']
